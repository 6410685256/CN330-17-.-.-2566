# Instructions

## Normal flow

- install node
- install dependencies
- create node app
- test app
- containerise app (create Dockerfile/docker-compose.yml)
- deploy

## Create a shell script to run shell with node in container

Create file `alias.sh`

Activate aliases in current shell.

**RUN:**

```console
. aliash.sh
```

Chekck alias in current shell.

**RUN:**

```console
alias
```

## Install node

Use `node` docker image from docker hub.

## Install dependencies

Install express framework to generate basic node app skeleton.

Run container using alias from `alias.sh`.

**RUN:**

```console
run_node
```

In the running container, run

**RUN:**

```console
npm install -g express-generator
express -v pug myapp
```

Since we are running as user `node` in container,
this installation will fail with permission error.

## Create express app

Create a basic node app with express framework using express-generator

In the container, run

**RUN:**

```console
npx express-generator -v pug myapp
```

Change directory to `src`

**RUN:**

```console
mv myapp src
```

## Install node packages in dependencies

In the container, run

**RUN:**

```console
cd /app/src
npm install
```

If there is any vulnerability, fix it as suggested by the output from
`npm install`, until all vulnerabilities are removed, e.g.

**RUN:**

```console
npm audit fix
npm audit fix --force
```

## Test running app

In the container, run with debug mode enabled

**RUN:**

```console
DEBUG=myapp:* npm start
```

Or run in production mode

**RUN:**

```console
npm start
```

Use web client to open URL:<http://localhost:3300>

To stop the app, type `Ctr + c`

To exit the container, type `Ctr + d` or `exit`

## Create Dockerfile and docker compose file

Use VS Code extension to create Dockerfile and docker-compose.yml

In VS Code, open command pallete,
run **`Docker: Add Docker Files to Workspace`**

From menu selection, choose:

- Select Application Platform: **Node.js**
- Choose a package.json file: **src\package.json**
- Port: **3000**
- Include optional Docker Compose file?: **Yes**

## Move files

**RUN:**

```console
mv src/.dockerignore .
mv src/Dockerfile .
```

## Edit Dockerfile

```Dockerfile
#=====================================================================
# DEVELOPMENT
#=====================================================================
FROM node:20.9.0-alpine3.18 as dev
ENV NODE_ENV=development

WORKDIR /app/src

COPY package*.json ./
RUN  npm install
# COPY --chown=node ./ ./

EXPOSE 3000
USER node

CMD ["node", "--inspect=0.0.0.0:9229", "./bin/www"]
# CMD ["nodemon", "-e", "js,mjs,cjs,json,pug", "--inspect=0.0.0.0:9229", "./bin/www"]

#=====================================================================
# PRODUCTION
#=====================================================================
FROM node:20.9.0-alpine3.18 as prod
ENV NODE_ENV=production

WORKDIR /app/src

COPY package*.json ./
RUN  npm install
COPY --chown=node ./ ./

EXPOSE 3000
USER node

CMD ["npm", "start"]
```

## Edit docker-compose.yml file

```docker-compose
version: '3.4'

services:
  myapp:
    image: my_app_node
    build:
      context: ./src/
      dockerfile: ../Dockerfile
      target: dev
      #target: prod
    volumes:
      - ./src:/app/src
    ports:
      - 3000:3000
      - 9229:9229
```

## Build image

```console
docker compose build
```

## Test running app with docker compose

```console
docker compose up
docker compose up -d
```

Use web client to open URL:<http://localhost:3000>

## Check log

```console
dcoker compose logs
docker compose logs -f
docker compose logs -f myapp
```
